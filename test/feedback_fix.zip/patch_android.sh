#!/bin/bash
# Android-এর MainActivity ও Manifest-এ কম্পন/শব্দের কোড বসায়।
set -e
KT=$(find android/app/src/main/kotlin -name MainActivity.kt | head -n 1)
if [ -z "$KT" ]; then echo "MainActivity.kt পাওয়া যায়নি। প্রজেক্টের মূল ফোল্ডারে আছেন তো?"; exit 1; fi
PKG=$(grep -m1 '^package ' "$KT" | awk '{print $2}')
echo "Package: $PKG"

cat > "$KT" <<'EOF'
package PKG_PLACEHOLDER

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var tone: ToneGenerator? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.azmain.islamic_app/feedback")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "vibrate" -> {
                        vibrateFor((call.argument<Int>("ms") ?: 30).toLong())
                        result.success(null)
                    }
                    "click" -> {
                        playClick()
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    @Suppress("DEPRECATION")
    private fun vibrateFor(ms: Long) {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (v == null || !v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            v.vibrate(ms)
        }
    }

    private fun playClick() {
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 60)
        } catch (e: Exception) {
            // শব্দ না চললে অ্যাপ চলতে থাকবে
        }
    }

    override fun onDestroy() {
        tone?.release()
        tone = null
        super.onDestroy()
    }
}
EOF
sed -i "s/PKG_PLACEHOLDER/$PKG/" "$KT"

MANIFEST=android/app/src/main/AndroidManifest.xml
if grep -q 'android.permission.VIBRATE' "$MANIFEST"; then
  echo "VIBRATE permission আগে থেকেই আছে"
else
  sed -i 's#<application#<uses-permission android:name="android.permission.VIBRATE"/>\n    <application#' "$MANIFEST"
  echo "VIBRATE permission যোগ হয়েছে"
fi
echo "সম্পন্ন!"
