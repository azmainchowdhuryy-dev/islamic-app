import 'package:flutter/services.dart';

/// কম্পন ও শব্দ।
/// প্রথমে Android-এর নিজস্ব কোড (MainActivity) দিয়ে চেষ্টা করে, যা ফোনের
/// "touch feedback/touch sound" সেটিং-এর ওপর নির্ভর করে না।
/// সেটি না পেলে (যেমন টেস্টে) Flutter-এর সাধারণ পদ্ধতিতে ফিরে যায়।
class FeedbackService {
  static const MethodChannel _channel = MethodChannel('com.azmain.islamic_app/feedback');

  static Future<void> _try(Future<void> Function() primary, Future<void> Function() fallback) async {
    try {
      await primary();
    } catch (_) {
      try {
        await fallback();
      } catch (_) {
        // কম্পন/শব্দ না চললেও অ্যাপ যেন ক্র্যাশ না করে।
      }
    }
  }

  /// [strong] = true হলে লম্বা কম্পন (লক্ষ্য পূর্ণ হলে)।
  static void tap({required bool vibration, required bool sound, bool strong = false}) {
    if (vibration) {
      _try(
        () => _channel.invokeMethod<void>('vibrate', {'ms': strong ? 250 : 30}),
        () => strong ? HapticFeedback.heavyImpact() : HapticFeedback.lightImpact(),
      );
    }
    if (sound) {
      _try(
        () => _channel.invokeMethod<void>('click'),
        () => SystemSound.play(SystemSoundType.click),
      );
    }
  }
}
